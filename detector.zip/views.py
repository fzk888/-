import os
# 一定要在 import YOLO 之前设置
os.environ["YOLO_OFFLINE"] = "True"

import cv2
from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from ultralytics import YOLO

# ─── 完整、已补全的“编码 → 中文说明” 对照字典 ─────────────────────────
SIGN_DESCRIPTION = {
    # 警告标志（黄色三角形）
    "w1":  "注意傍山险路（左侧）",
    "w2":  "注意傍山险路（右侧）",
    "w3":  "注意村庄",
    "w4":  "注意渡口",
    "w5":  "注意堤坝路",
    "w6":  "注意双向交通",
    "w7":  "注意窄桥",
    "w8":  "注意分离式道路",
    "w9":  "注意滑坡",
    "w10": "注意向右急转弯",
    "w11": "注意向左急转弯",
    "w12": "注意路面不平",
    "w13": "注意十字交叉路口",
    "w14": "注意T型交叉路口（直行）",
    "w15": "注意左侧来车",
    "w16": "注意右侧来车",
    "w17": "注意Y型交叉路口（左侧）",
    "w18": "注意分离式道路",
    "w19": "注意Y型交叉路口（右侧）",
    "w20": "注意T型交叉路口（直行尽头）",
    "w21": "注意T型交叉路口（左侧）",
    "w22": "注意T型交叉路口（右侧）",
    "w23": "注意环形交叉路口",
    "w24": "注意连续弯路",
    "w25": "注意陡坡",
    "w26": "注意路面不平（颠簸路）",
    "w27": "注意雨天路滑",
    "w28": "注意低洼路面",
    "w29": "注意路面凸起",
    "w30": "注意慢行",
    "w31": "注意左侧滑坡",
    "w32": "注意施工",
    "w33": "注意潮汐车道",
    "w34": "注意事故易发路段",
    "w35": "注意会车",
    "w36": "注意野生动物",
    "w37": "注意隧道",
    "w38": "注意涵洞",
    "w39": "注意拱桥",
    "w40": "注意铁路道口",
    "w41": "注意右侧落石",
    "w42": "注意向右急转弯",
    "w43": "注意向左急转弯",
    "w44": "注意路面结冰",
    "w45": "注意信号灯",
    "w46": "注意有人看守铁路道口",
    "w47": "注意窄桥",
    "w48": "注意右侧变窄",
    "w49": "注意左侧变窄",
    "w50": "注意路面高突",
    "w51": "注意雷雨天气",
    "w52": "注意残疾人设施",
    "w53": "注意潮汐车道",
    "w54": "注意雾天",
    "w55": "注意儿童",
    "w56": "注意非机动车",
    "w57": "注意人行横道",
    "w58": "注意右侧车辆汇入",
    "w59": "注意左侧车辆汇入",
    "w60": "注意横风",
    "w61": "注意冰雪天气",
    "w62": "注意右侧落石",
    "w63": "注意危险",
    "w64": "注意牲畜",
    "w65": "注意右侧变窄且向上",
    "w66": "注意交叉路口",
    "w67": "注意车辆排队",

    # 禁令标志（红色圆圈）
    "p1":  "禁止向左转弯",
    "p2":  "禁止畜力车进入",
    "p3":  "禁止大型客车进入",
    "p4":  "禁止三轮车进入",
    "p5":  "禁止掉头",
    "p6":  "禁止非机动车进入",
    "p7":  "禁止向左转弯",
    "p8":  "禁止挂车、半挂车进入",
    "p9":  "禁止行人进入",
    "p10": "禁止机动车进入",
    "p11": "禁止鸣喇叭",
    "p12": "禁止摩托车进入",
    "p13": "禁止农用运输车进入",
    "p14": "禁止直行",
    "p15": "禁止人力车进入",
    "p16": "禁止骑自行车带人",
    "p17": "禁止非机动车载人",
    "p18": "禁止拖拉机进入",
    "p19": "禁止向右转弯",
    "p20": "禁止向左和向右转弯",
    "p21": "禁止直行和向右转弯",
    "p22": "禁止拖拉机进入",
    "p23": "禁止向左转弯",
    "p24": "禁止向左转弯",
    "p25": "禁止小型客车进入",
    "p26": "禁止大型货车进入",
    "p27": "禁止机动车鸣喇叭",
    "p28": "禁止直行和向左转弯",

    # 其他禁令标志
    "pm":  "限制质量",
    "pa":  "限制轴重",
    "pd":  "解除禁止超车",
    "pc":  "解除禁止掉头",
    "pn":  "禁止停车",
    "pnl": "禁止长时停车",
    "pl":  "限速",
    "pr":  "解除限速",
    "ph":  "限制高度",
    "pw":  "限制宽度",
    "ps":  "停车让行",
    "pg":  "减速让行",
    "pb":  "禁止通行",
    "pe":  "禁止双向通行",
    "pne": "禁止驶入",

    # 指示标志（蓝色圆形）
    "i1":  "步行（行人专用道路）",
    "i2":  "非机动车行驶",
    "i3":  "环岛行驶",
    "i4":  "机动车行驶",
    "i5":  "靠右侧道路行驶",
    "i6":  "靠左侧道路行驶",
    "i7":  "直行和右转合用车道",
    "i8":  "直行和左转合用车道",
    "i9":  "鸣喇叭",
    "i10": "向右转弯",
    "i11": "分向行驶车道",
    "i12": "向左转弯",
    "i13": "直行",
    "i14": "直行和向右转弯",
    "i15": "直行和向左转弯",
    "ip":  "停车",
    "il":  "限速"
}


# ── 加载本地 YOLOv12 模型 ─────────────────
MODEL_PATH = os.path.join("model","exp_TT100K2", "weights", "best.pt")
model = YOLO(MODEL_PATH)


def detect_traffic_sign(request):
    context = {}
    if request.method == 'POST' and request.FILES.get('image'):
        # 1. 保存上传图片
        img_file = request.FILES['image']
        fs = FileSystemStorage()
        filename = fs.save(f"uploads/{img_file.name}", img_file)
        img_path = fs.path(filename)

        # 2. 离线推理并绘制检测框
        results = model(img_path)[0]
        result_img = results.plot()
        result_filename = f"uploads/result_{img_file.name}"
        result_path = fs.path(result_filename)
        cv2.imwrite(result_path, result_img)

        # 3. 提取被识别到的编码列表，去重保留顺序
        detected = []
        for cls_idx in results.boxes.cls.cpu().numpy().astype(int):
            code = results.names[cls_idx]
            detected.append(code)
        seen = set()
        detected_codes = []
        for c in detected:
            if c not in seen:
                seen.add(c)
                detected_codes.append(c)

        # 4. 把字典转为已排序的列表，按编码升序，并处理动态标志
        sorted_sign_desc = []
        for code, desc in sorted(SIGN_DESCRIPTION.items(), key=lambda x: x[0]):
            if code in ['pm', 'pa', 'pl', 'pw', 'pr', 'ph', 'il']:
                for detected_code in detected_codes:
                    if detected_code.startswith(code):
                        value = detected_code[len(code):]
                        unit = ''
                        if code in ['pl', 'pr', 'il']:
                            unit = '公里/小时'
                        elif code in ['pm', 'pa']:
                            unit = '吨'
                        elif code in ['ph', 'pw']:
                            unit = '米'
                        new_desc = f"{desc}{value} {unit}"
                        sorted_sign_desc.append((detected_code, new_desc))
            else:
                sorted_sign_desc.append((code, desc))

        # 5. 传给模板
        context["uploaded_img"]     = fs.url(filename)
        context["result_img"]       = fs.url(result_filename)
        context["detected_codes"]   = detected_codes
        context["sorted_sign_desc"] = sorted_sign_desc

    return render(request, "detector/index.html", context)