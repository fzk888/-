from django.contrib import admin
from django.urls import path
from detector.views import detect_traffic_sign
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', detect_traffic_sign, name='home'),  # 首页绑定识别视图
    path('admin/', admin.site.urls),
]

# 允许开发环境访问 media 文件（上传图片、识别结果）
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
