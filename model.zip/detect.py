from ultralytics import YOLO
import cv2
import numpy as np

if __name__ == '__main__':
    # Load a model
    model = YOLO(model=r'/workspace/runs/train/exp_TT100K2/weights/best.pt')
    
    # 获取模型的类别名称
    class_names = model.names
    
    # 执行预测
    results = model.predict(source=r'/workspace/w13.png',
                             save=True,
                             show=False,
                             )
    
    # 加载原始图像
    img = cv2.imread(r'/workspace/w13.png')
    
    # 遍历每个预测结果
    for result in results:
        # 获取预测框和类别
        boxes = result.boxes
        for box in boxes:
            cls = int(box.cls[0].item())  # 获取类别索引
            xyxy = box.xyxy[0].cpu().numpy().astype(int)  # 获取边界框坐标
            
            # 绘制边界框
            cv2.rectangle(img, (xyxy[0], xyxy[1]), (xyxy[2], xyxy[3]), (0, 255, 0), 2)
            
            # 在图像上绘制类别序号
            cv2.putText(img, str(cls), (xyxy[0], xyxy[1] - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
    
    # 保存修改后的图像
    cv2.imwrite('output_image.png', img)