import os
import json
import shutil
import cv2
from tqdm import tqdm
from collections import defaultdict

class TT100K2COCO:
    def __init__(self, parent_path, target_root):
        """
        参数:
            parent_path: 存放 TT100K 原始 JSON 和所有图片的根目录，
                         例如 r"C:\新建文件夹\tt100k_2021"
            target_root: 分割后 train/val/test 图片要拷贝到的根目录，
                         例如 r"C:\新建文件夹"
        """
        self.parent_path = parent_path  # 例: r"C:\新建文件夹\tt100k_2021"
        self.target_root = target_root  # 例: r"C:\新建文件夹"
        self.annotation_file = os.path.join(self.parent_path, "annotations_all.json")
        self.stats_file = os.path.join(self.parent_path, "statistics.json")

    def class_statistics(self, min_samples=100):
        """
        1) 读取 annotations_all.json
        2) 统计每个类别出现的不同图片数
        3) 只保留出现次数 >= min_samples 的类别，并把它们所属的所有图片列表写入 statistics.json
        """
        print("[Phase 1] 开始统计每个类别对应的图片 ...")
        with open(self.annotation_file, "r", encoding="utf-8") as f:
            origin = json.load(f)
        types = origin["types"]
        imgs = origin["imgs"]

        # 统计每个类别出现过的图片名称集合
        sta = {cls: set() for cls in types}
        for img_id, info in imgs.items():
            img_name = os.path.basename(info["path"])
            for obj in info["objects"]:
                cls = obj["category"]
                sta[cls].add(img_name)

        # 只保留出现次数 >= min_samples 的类别
        filtered = {k: list(v) for k, v in sta.items() if len(v) >= min_samples}
        types_keep = list(filtered.keys())
        images_keep = set()
        for v in filtered.values():
            images_keep.update(v)

        result = {
            "type": types_keep,          # 保留的类别列表
            "details": filtered,         # {类别名: [图片1.jpg, 图片2.jpg, ...], ...}
            "images": list(images_keep)  # 所有保留类别对应的图片集合
        }

        # 写 statistics.json
        os.makedirs(os.path.dirname(self.stats_file), exist_ok=True)
        with open(self.stats_file, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"[Phase 1] 已保存 statistics.json 到: {self.stats_file}，共保留 {len(types_keep)} 个类别，{len(images_keep)} 张图片。\n")

    def original2coco(self):
        """
        1) 读取 statistics.json，拿到需要保留的类别和图片列表
        2) 读取 annotations_all.json，遍历所有图片，计算每张图“归属”到哪个类别
           （即图片里某保留类别实例数最多的那个类别）
        3) 按每个类别图片数量的 70%/20%/10% 划分到 train/val/test，
           同时把图片拷贝到 target_root/{train,val,test}/ 下
        4) 按 COCO 格式组织 metadata：images + annotations + categories + info + licenses
        5) 写出 train.json、val.json、test.json 到 parent_path\dataset\annotations\ 下
        """
        print("[Phase 2] 开始加载 statistics.json ...")
        with open(self.stats_file, "r", encoding="utf-8") as f:
            stats = json.load(f)
        types_keep = stats["type"]
        images_keep = set(stats["images"])  # 仅保留这些图片

        print("[Phase 2] 开始加载 annotations_all.json ...")
        with open(self.annotation_file, "r", encoding="utf-8") as f:
            origin = json.load(f)
        imgs = origin["imgs"]

        # 3.1 计算每张图片的 own_type（出现最多的保留类别）
        print("[Phase 2] 计算每张图片归属的类别（own_type）并统计每个类别的图片总数 ...")
        own_type_map = {}                    # img_name -> own_type
        owntype_sum = {cls: 0 for cls in types_keep}  # 每个类别共有多少张图片
        for img_id, info in imgs.items():
            img_name = os.path.basename(info["path"])
            if img_name not in images_keep:
                continue
            counter = {}
            for obj in info["objects"]:
                cls = obj["category"]
                if cls in types_keep:
                    counter[cls] = counter.get(cls, 0) + 1
            if not counter:
                continue
            own = max(counter, key=counter.get)
            own_type_map[img_name] = own
            owntype_sum[own] += 1

        # 3.2 构建空的 COCO 结构
        def make_empty_coco():
            return {
                "info": {
                    "year": 2021,
                    "version": "1.0",
                    "description": "TT100K_to_coco",
                    "contributor": "Tecent&Tsinghua",
                    "url": "https://cg.cs.tsinghua.edu.cn/traffic-sign/",
                    "date_created": "2021-01-15"
                },
                "licenses": [{"id": 1, "name": "null", "url": "null"}],
                "categories": [],
                "images": [],
                "annotations": []
            }

        train_coco = make_empty_coco()
        val_coco   = make_empty_coco()
        test_coco  = make_empty_coco()

        # 3.3 构建 categories 字段: id 从 0 开始
        label_map = {cls: idx for idx, cls in enumerate(types_keep)}
        for cls, idx in label_map.items():
            cat = {"id": idx, "name": cls, "supercategory": "traffic_sign"}
            train_coco["categories"].append(cat)
            val_coco["categories"].append(cat)
            test_coco["categories"].append(cat)

        # 4) 遍历所有保留图片，按 own_type 分配到 train/val/test
        print("[Phase 2] 遍历所有保留图片，按比例分配到 train/val/test 并填充 COCO 数据 ...")
        count = {cls: 0 for cls in types_keep}  # 已经分配到 train/val/test 的计数
        obj_id = 1
        for img_id, info in tqdm(imgs.items(), desc="划分图片"):
            img_path_rel = info["path"]         # 类似 "train/84351.jpg"
            img_name = os.path.basename(img_path_rel)
            if img_name not in images_keep:
                continue

            own = own_type_map.get(img_name, None)
            if own is None:
                continue

            current_count = count[own]
            total_for_cls = owntype_sum[own]
            ratio = current_count / total_for_cls

            if ratio < 0.7:
                target_set = train_coco
                subset = "train"
            elif ratio < 0.9:
                target_set = val_coco
                subset = "val"
            else:
                target_set = test_coco
                subset = "test"
            count[own] += 1

            # 4.1 拷贝图片到 target_root/{train,val,test}/
            src_img = os.path.join(self.parent_path, img_path_rel)
            dst_dir = os.path.join(self.target_root, subset)
            os.makedirs(dst_dir, exist_ok=True)
            dst_img = os.path.join(dst_dir, img_name)
            shutil.copyfile(src_img, dst_img)

            # 4.2 读取图像尺寸
            im = cv2.imread(src_img)
            if im is None:
                print(f"  [WARN] 无法读取图片: {src_img}，跳过该图片尺寸统计。")
                continue
            H, W = im.shape[:2]

            # 4.3 填 images 字段
            target_set["images"].append({
                "file_name": img_name,
                "id": int(img_id),
                "width": W,
                "height": H
            })

            # 4.4 填 annotations 字段
            for obj in info["objects"]:
                cls = obj["category"]
                if cls not in types_keep:
                    continue
                xmin = obj["bbox"]["xmin"]
                ymin = obj["bbox"]["ymin"]
                xmax = obj["bbox"]["xmax"]
                ymax = obj["bbox"]["ymax"]
                w = xmax - xmin
                h = ymax - ymin
                ann = {
                    "id": obj_id,
                    "image_id": int(img_id),
                    "category_id": label_map[cls],
                    "bbox": [xmin, ymin, w, h],
                    "area": w * h,
                    "iscrowd": 0,
                    "segmentation": [[xmin, ymin, xmax, ymin, xmax, ymax, xmin, ymax]]
                }
                target_set["annotations"].append(ann)
                obj_id += 1

        # 5) 将 train/val/test COCO 保存到 parent_path\dataset\annotations\
        print("[Phase 2] 将 COCO 格式保存到硬盘 ...")
        for subset, coco_data in zip(["train", "val", "test"], [train_coco, val_coco, test_coco]):
            save_dir = os.path.join(self.parent_path, "dataset", "annotations")
            os.makedirs(save_dir, exist_ok=True)
            save_path = os.path.join(save_dir, f"{subset}.json")
            with open(save_path, "w", encoding="utf-8") as f:
                json.dump(coco_data, f, ensure_ascii=False, indent=2)
            print(f"  已保存 {subset}.json: {save_path}")
        print("[Phase 2] 完成 COCO 格式转换并分割。\n")

    def coco2yolo(self, subset, images_dir, yolo_label_dir):
        """
        将指定 subset（train/val/test）的 COCO JSON 转成 YOLO txt 文件：
        - subset: 'train' / 'val' / 'test'
        - images_dir: 该 subset 下的图片文件夹（例如 C:\新建文件夹\train）
        - yolo_label_dir: 输出的 YOLO txt 文件所在文件夹
        """
        print(f"[Phase 3] 开始将 {subset} 集从 COCO 转为 YOLO 格式 ...")

        coco_json = os.path.join(self.parent_path, "dataset", "annotations", f"{subset}.json")
        with open(coco_json, "r", encoding="utf-8") as f:
            data = json.load(f)

        # 将 annotations 按 image_id 分组，查找速度更快
        anns_by_img = defaultdict(list)
        for ann in data["annotations"]:
            anns_by_img[ann["image_id"]].append(ann)

        # COCO category_id → YOLO 类别 id（从 0 开始）
        id_map = {c["id"]: idx for idx, c in enumerate(data["categories"])}

        # 创建输出目录
        os.makedirs(yolo_label_dir, exist_ok=True)

        def convert(size, bbox):
            dw = 1.0 / size[0]
            dh = 1.0 / size[1]
            x = bbox[0] + bbox[2] / 2.0
            y = bbox[1] + bbox[3] / 2.0
            w = bbox[2]
            h = bbox[3]
            xc = round(x * dw, 6)
            yc = round(y * dh, 6)
            wc = round(w * dw, 6)
            hc = round(h * dh, 6)
            return xc, yc, wc, hc

        for img in tqdm(data["images"], desc=f"生成 {subset} YOLO txt"):
            img_id = img["id"]
            fname = img["file_name"]        # e.g. "84351.jpg"
            W, H = img["width"], img["height"]
            label_txt = os.path.join(yolo_label_dir, fname.replace(".jpg", ".txt"))

            with open(label_txt, "w") as fw:
                for ann in anns_by_img[img_id]:
                    yolo_cls = id_map[ann["category_id"]]
                    x_center, y_center, w_rel, h_rel = convert((W, H), ann["bbox"])
                    fw.write(f"{yolo_cls} {x_center} {y_center} {w_rel} {h_rel}\n")

        print(f"[Phase 3] 完成 {subset} 的 YOLO txt 生成，保存在: {yolo_label_dir}\n")


if __name__ == "__main__":
    # ===== 注意：请将下面两个路径修改为你电脑上的实际目录 =====
    # parent_path: 存放 TT100K 原始 JSON 和所有图片的根目录
    # target_root: 分割后 train/val/test 图片要拷贝到的根目录
    parent = r"C:\新建文件夹\tt100k_2021\tt100k_2021"
    target = r"C:\新建文件夹\tt100k_2021"

    converter = TT100K2COCO(parent_path=parent, target_root=target)

    # Phase 1: 统计并筛选类别
    converter.class_statistics(min_samples=100)

    # Phase 2: 将 TT100K 原始 JSON 转为 COCO 格式并分割 train/val/test
    converter.original2coco()

    # Phase 3: 把 COCO JSON 转为 YOLO txt
    #   images_dir 需指向分割后对应的图片文件夹 (target + '\train', '\val', '\test')
    #   yolo_label_dir 可以自行指定，例如在 parent 下新建一个 yolo_labels 文件夹
    converter.coco2yolo(
        subset="train",
        images_dir=os.path.join(target, "train"),
        yolo_label_dir=os.path.join(parent, "yolo_labels", "train")
    )
    converter.coco2yolo(
        subset="val",
        images_dir=os.path.join(target, "val"),
        yolo_label_dir=os.path.join(parent, "yolo_labels", "val")
    )
    converter.coco2yolo(
        subset="test",
        images_dir=os.path.join(target, "test"),
        yolo_label_dir=os.path.join(parent, "yolo_labels", "test")
    )

    print("==== 全部处理完毕！ ====")
