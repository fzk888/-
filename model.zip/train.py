from ultralytics import YOLO
import warnings

warnings.filterwarnings('ignore')

if __name__ == '__main__':
    # 初始化模型，加载预训练权重
    model = YOLO('/workspace/runs/train/exp_TT100K2/weights/last.pt')  

    model.train(
        data=r'/workspace/yolov12-main/data.yaml',  # data.yaml 路径
        imgsz=960,         # 建议从 960 开始试，若显存足够可直接 1280
        batch=16,          # 16 较为安全，若 960×16 OOM，可以调成 12 或 8
        workers=8,         # CPU 8 核，设置 8 个线程利用率最高
        device='0',        # 单卡 GPU id=0；若有多卡可改成 '0,1' 等
        optimizer='SGD',
        momentum=0.937,    # Ultralytics 默认动量
        weight_decay=0.0005,
        lr0=0.01,          # 初始学习率（可略微调小/调大，和 batch 有关）
        lrf=0.1,           # 最终学习率比例
        epochs=100,        # 总训练轮数，可根据训练曲线再改
        close_mosaic=10,   # 最后 10 轮关闭 Mosaic
        resume=True,
        project='runs/train',
        name='exp_TT100K',
        single_cls=False,
        cache='disk',      # 32 GB 内存可以尝试改成 'ram'，不过 'disk' 更保险
        amp=True,          # 混合精度，加速并节省显存
        patience=30,       # 验证集指标 30 轮无提升则早停
        augment=True       # 启用数据增强
    )
